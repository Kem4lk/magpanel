G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.9-8.0.9-0~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-10-02T00:00:00+00:00*
G04 #@! TF.ProjectId,magpanel-carrier-diy,6d616770-616e-4656-9c2d-636172726965,1.2*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.9-8.0.9-0~ubuntu24.04.1) date 2026-10-02 00:00:00*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
X3500000Y3500000D03*
X3500000Y60000000D03*
X96500000Y60000000D03*
X96500000Y3500000D03*
M02*
